#!/system/bin/sh
/system/bin/rb_ua -c /system/etc/rb_ua.conf --in_recovery_kernel=0 --recovery_command=rb_ignore --set_boot_to_recovery=0
